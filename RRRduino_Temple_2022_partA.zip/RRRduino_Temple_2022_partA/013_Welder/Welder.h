// Welder.h
#ifdef WELDER
#else
#define WELDER

#define SPARKSRANDOM        100
#define SMALLRANDOM         100
#define WELDEROFFRANDOM     150
#define LONGRANDOM          160


class Welder {
private:
  unsigned char state;         // 'o' short on, 'f' short off, 'F' long off
  unsigned int randomOn;
  unsigned int randomOnTime;
  unsigned int randomOffTime;
  unsigned int randomLongOffTime;
  
  unsigned int sparksRANDOM;
  unsigned int smallRANDOM;
  unsigned int offRANDOM;
  unsigned int longRANDOM;
 
  bool onWhen;
  unsigned char pin;
  unsigned long now;
  unsigned long previous;
  
protected:
  bool enabled = false;

public:
  Welder( int thePin, unsigned int theOFFRANDOM, bool theTurnOnWhenSetting, unsigned int theSPARKSRANDOM = SPARKSRANDOM,
              unsigned int theSMALLRANDOM = SMALLRANDOM, unsigned int theLONGRANDOM = LONGRANDOM ) {
    sparksRANDOM  = theSPARKSRANDOM;
    smallRANDOM   = theSMALLRANDOM;
    offRANDOM     = theOFFRANDOM;
    longRANDOM    = theLONGRANDOM;
    
    setPinAndMode( thePin, theTurnOnWhenSetting );
  } // Welder( int, unsigned int, bool, [unsigned int], [unsigned int], [unsigned int] )

  void setPinAndMode( unsigned char thePin, bool theTurnOnWhenSetting ) {
    pin = thePin;
    onWhen = theTurnOnWhenSetting; 
  } // setPinMode( unsigned char, bool )


  void begin( ) {
    enable( );
    on( );
    state         = 'f';
    
    randomOn      = random( 0, sparksRANDOM );
    randomOnTime  = random( 0, smallRANDOM );
    randomOffTime = random( 0, smallRANDOM );

    pinMode( pin, OUTPUT );
    //..Serial.print( pin, DEC ); Serial.print( F(":") );Serial.println( onWhen, DEC );
    delay( 100 );
  } // begin( )

  
  void on( ) {
    digitalWrite( pin, onWhen );
  } // on( )


  void onPrint( ) {
    Serial.print( F("p[") ); Serial.print( pin, DEC ); Serial.print( F("]:") );
    Serial.println( F("On") );
    on( );
  } // onPrint( )


  void off( ) {
    digitalWrite( pin, !onWhen );
  } // off( )


  void offPrint( ) {
    Serial.print( F("p[") ); Serial.print( pin, DEC ); Serial.print( F("]:") );
    Serial.println( F("Off") );
    off( );
  } // offPrint( )


  void enable( ) {
    enabled = true;
    now = previous = millis( );
  } // enable( )
  

  void setEnabled( bool newState ) {
    if( newState ) {
      enable( );
    } else
      disable( );
  } // setEnabled( bool )


  void disable( ) {
    digitalWrite( pin, !onWhen );
    enabled = false;
  } // disable( )

  
  void update( ) {
    now = millis( );
    if( enabled ) {
      switch( state ) {
        case 'f': // we turn on here if onTime expired
           if ( now - previous >= randomOnTime ) {
             previous = now;
             randomOffTime = random( 0, smallRANDOM );
             on( );
             state = 'o';
           } // if
          break;
        case 'o': // we turn off here if offTime expired,
                  // and check if it is time to rest
          if ( now - previous >= randomOffTime ) {
            previous = now;
            randomOnTime = random( 0, smallRANDOM );
            off( );
            randomOn--;
            if ( randomOn == 0 ) {
              randomLongOffTime = random( 0, offRANDOM ) * random( 0, longRANDOM );
              state = 'F';
            } else { state = 'f'; }
          } // if
          break;
        case 'F':
           if ( now - previous >= randomLongOffTime ) {
             previous = now;
             randomOnTime = random( 0, smallRANDOM );
             randomOn = random( 0, sparksRANDOM );
             off( );
             state = 'f';
           } // if
          break;

        default: break;
      } // switch
    } // if enabled
  } // update( )

}; // class Welder

/******************************* END OF FILE **********************************/
#endif
